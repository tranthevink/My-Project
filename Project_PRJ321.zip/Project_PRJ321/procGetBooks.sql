--drop proc GetBook

use BookShopDB
go
create proc GetBooks
@first int,
@second int
as 
begin
	select t.* from 
	(
		select *, ROW_NUMBER() over (order by BookID) as RowID
		from Books t
	) t
	where t.RowID >= @first and t.RowID <= @second
end

--test proc
exec GetBooks 6, 26

