
package com.model;

import com.context.DBContext;
import com.entity.Category;
import com.entity.Book;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.dao.BookDAO;

public class DBModel implements Serializable {
    private int page, pageSize;
    private String bookName, categoryID, categoryName, bookID, descriptionBookType;

    public String getDescriptionBookType() {
        return descriptionBookType;
    }
    
    public void setDescriptionBookType(String descriptionBookType) {
        this.descriptionBookType = descriptionBookType;
    }

    public String getBookID() {
        return bookID;
    }

    public void setBookID(String bookID) {
        BookDAO b = new BookDAO();
        this.bookID = bookID;
        try {
            List<Book> classesList =b.getAllBooks();
            for(Book x : classesList) {
                if((x.getBookID()+"").equals(bookID)) {
                    bookName = x.getBookName();
                }
            }
        } catch (Exception e) {
        }
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public void setCategoryID(String categoryID) {
       
        this.categoryID = categoryID;
        BookDAO b = new BookDAO();
        try {
            List<Category> classesList = b.getAllCategories();
            for(Category x : classesList) {
                if((x.getCategoryID()+"").equals(categoryID)) {
                    categoryName = x.getCategoryName();
                    descriptionBookType = x.getDescription();
                }
            }
        } catch (Exception e) {
        }
    }

    public String  getCategoryID() throws Exception {
        
        return categoryID;
    }
    //
    
    public List<Book>  getBooksCategoryID() throws Exception {
        
        return new BookDAO().getBooksByCategory(categoryID);//categoryID;
    }

     public List<Book> getBookDetail() throws Exception{
         return new BookDAO().getBookDetail(this.bookID);
     }
     

    

    
    
    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }
    
    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
    
    
    
    // Chua lam nha tai tro
    
//    public List<Supplier> getAllSuppliers() throws Exception {
//        List<Supplier> s = new ArrayList<>();
//        String query = "select * from Suppliers";
//        Connection conn = new DBContext().getConnection();
//        PreparedStatement ps = conn.prepareStatement(query);
//        ResultSet rs = ps.executeQuery();
//        while(rs.next()) {
//            int supplierID = rs.getInt(1);
//            String supplierName = rs.getString(2);
//            String address = rs.getString(3);
//            String phone = rs.getString(4);
//            s.add(new Supplier(supplierID, supplierName, address, phone));
//        }
//        rs.close();
//        conn.close();
//        return s;
//    }
    
    
    
    public int getTotalPages() throws Exception {
        BookDAO b = new BookDAO();
        return 1 + b.getTotalBooks()/ pageSize;
    }

    public DBModel() {
        pageSize = 8;
        page = 1;
    }
    
    public List<Book> getBooks() throws Exception {
        List<Book> t = new ArrayList<>();
        if(page == 0) page = 1;
        if(pageSize == 0) pageSize = 8;
        int from = (page  - 1) * pageSize + 1;
        int to = page * pageSize;
        String query = "exec GetBooks ?, ?";
              Connection conn = new DBContext().getConnection();
        CallableStatement cs = conn.prepareCall(query);
        cs.setInt(1, from);
        cs.setInt(2, to);
        ResultSet rs = cs.executeQuery();
        while(rs.next()) {
            int bookID = rs.getInt("bookid");
            String bookName = rs.getString("bookname");
            double unitPrice = rs.getDouble("unitprice");
            int available = rs.getInt("available");
            int unitInStock = rs.getInt("unitinstock");
            String image = rs.getString("image");
            t.add(new Book(bookID, bookName, unitPrice, available, unitInStock, image));
        }
        rs.close();
        conn.close();
        return t;
    }

    
    
    
    
   
    
    private String function;

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }
    
//    public boolean addNewBook(Book t) throws Exception {
//        String query = "insert into Books values (?,?,?,?,?,?,?,?,?,?)";
//        Connection conn = new DBContext().getConnection();
//        PreparedStatement ps = conn.prepareStatement(query);
//        ps.setNString(1, t.getBookName());
//        ps.setNString(2, t.getDescription());
//        ps.setDouble(3, t.getUnitPrice());
//        ps.setDate(4, new java.sql.Date(new Date().getTime()));
//        ps.setInt(5, t.getAvailable());
//        ps.setInt(6, t.getUnitInStock());
//        ps.setInt(7, 0);
//        ps.setInt(8, t.getCategoryID());
//        ps.setInt(9, t.getSupplierID());
//        ps.setNString(10, t.getImage());
//        int n = ps.executeUpdate();
//        conn.close();
//        ps.close();
//        return n != 0;
//    }
}

