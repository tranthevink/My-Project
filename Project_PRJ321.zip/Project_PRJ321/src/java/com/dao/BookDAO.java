/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.context.DBContext;
import com.entity.Book;
import com.entity.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author HungVu
 */
public class BookDAO {
    public List<Book> getAllBooks() throws Exception {
        List<Book> t = new ArrayList<>();
        String query = "select * from Books";
        Connection conn = new DBContext().getConnection();
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int bookID = rs.getInt("bookid");
            String bookName = rs.getString("bookname");
            String description = rs.getString("description");
            double unitprice = rs.getDouble("unitprice");
            Date dateCreated = rs.getDate("datecreated");
            int available = rs.getInt("available");
            int unitInStock = rs.getInt("unitinstock");
            int unitOnOrder = rs.getInt("unitonorder");
            int categoryID = rs.getInt("categoryID");
            int supplierID = rs.getInt("supplierID");
            String image = rs.getString("image");
            t.add(new Book(bookID, bookName, description, unitprice, dateCreated, available, unitInStock, unitOnOrder, categoryID, supplierID, image));
        }
        rs.close();
        conn.close();
        return t;
    }
    
    public List<Category> getAllCategories() throws Exception {
        List<Category> c = new ArrayList<>();
        String query = "select * from Categories";
        Connection conn = new DBContext().getConnection();
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int categoryID = rs.getInt(1);
            String categoryName = rs.getString(2);
            String description = rs.getString(3);
            c.add(new Category(categoryID, categoryName, description));
        }
        rs.close();
        conn.close();
        return c;
    }
    
    public List<Book> getBookDetail(String bookIDParam) throws Exception {
        Connection conn = new DBContext().getConnection();
        List<Book> t = new ArrayList<>();
        String query = "select * from Books where bookID = " + Integer.valueOf(bookIDParam);
        ResultSet rs = conn.prepareStatement(query).executeQuery();
        while(rs.next()) {
            int bookID = rs.getInt("bookid");
            String bookName = rs.getString("bookname");
            String description = rs.getString("description");
            double unitprice = rs.getDouble("unitprice");
            Date dateCreated = rs.getDate("datecreated");
            int available = rs.getInt("available");
            int unitInStock = rs.getInt("unitinstock");
            int unitOnOrder = rs.getInt("unitonorder");
            int categoryID = rs.getInt("categoryID");
            int supplierID = rs.getInt("supplierID");
            String image = rs.getString("image");
            t.add(new Book(bookID, bookName, description, unitprice, dateCreated, available, unitInStock, unitOnOrder, categoryID, supplierID, image));
        }
        conn.close();
        rs.close();
        return t;
    }
   
     public List<Book> getBooksByCategory(String categoryID) throws Exception {
        List<Book> t = new ArrayList<>();
        Connection conn = new DBContext().getConnection();
        String query = "select * from Books where categoryID = " + categoryID;
        ResultSet rs = conn.prepareStatement(query).executeQuery();
        while(rs.next()) {
            int bookID = rs.getInt("bookid");
            String bookName = rs.getString("bookname");
            double unitPrice = rs.getDouble("unitprice");
            int available = rs.getInt("available");
            int unitInStock = rs.getInt("unitinstock");
            String image = rs.getString("image");
            t.add(new Book(bookID, bookName, unitPrice, available, unitInStock, image));
        }
        conn.close();
        return t;
    }
     
     public List<Book> getBooksBySearch(String n) throws Exception {
        List<Book> t = new ArrayList<>();
        Connection conn = new DBContext().getConnection();
        String query = "select * from Books where bookName like N'%"+n+"%'";
        ResultSet rs = conn.prepareStatement(query).executeQuery();
        while(rs.next()) {
            int bookID = rs.getInt("BookID");
            String bookName = rs.getString("BookName");
            double unitPrice = rs.getDouble("UnitPrice");
            int available = rs.getInt("Available");
            int unitInStock = rs.getInt("UnitInStock");
            String image = rs.getString("Image");
            t.add(new Book(bookID, bookName, unitPrice, available, unitInStock, image));
        }
        conn.close();
        return t;
    }
     
     public int getTotalBooks() throws Exception {
        String query = "select count(*) from Books ";
        Connection conn = new DBContext().getConnection();
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int rows = 0;
        if(rs.next()) rows = rs.getInt(1);
        rs.close();
        conn.close();
        return rows;
    }
}
