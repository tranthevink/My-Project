package com.entity;

import java.util.Date;

public class Book {

    private int bookID;
    private String bookName;
    private String description;
    private double unitPrice;
    private Date dateCreated;
    private int available;
    private int unitInStock, unitOnOrder;
    private int categoryID, supplierID;
    private String image;

    public Book() {
    }

    public Book(int bookID, String bookName, double unitPrice, int available, int unitInStock, String image) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.unitPrice = unitPrice;
        this.available = available;
        this.unitInStock = unitInStock;
        this.image = image;
    }

    public Book(String bookName, String description, double unitPrice,
            Date dateCreated, int available, int unitInStock, int unitOnOrder, int categoryID, int supplierID, String image) {
        this.bookName = bookName;
        this.description = description;
        this.unitPrice = unitPrice;
        this.dateCreated = dateCreated;
        this.available = available;
        this.unitInStock = unitInStock;
        this.unitOnOrder = unitOnOrder;
        this.categoryID = categoryID;
        this.supplierID = supplierID;
        this.image = image;
    }
    
    

    public Book(int bookID, String bookName, double unitPrice, int available, String image) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.unitPrice = unitPrice;
        this.available = available;
        this.image = image;
    }
    
    public Book(int bookID, String bookName, String description, double unitPrice, Date dateCreated, int available, int unitInStock, int unitOnOrder, int categoryID, int supplierID, String image) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.description = description;
        this.unitPrice = unitPrice;
        this.dateCreated = dateCreated;
        this.available = available;
        this.unitInStock = unitInStock;
        this.unitOnOrder = unitOnOrder;
        this.categoryID = categoryID;
        this.supplierID = supplierID;
        this.image = image;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public int getAvailable() {
        return available;
    }

    public void setAvailable(int available) {
        this.available = available;
    }


    public int getUnitInStock() {
        return unitInStock;
    }

    public void setUnitInStock(int unitInStock) {
        this.unitInStock = unitInStock;
    }

    public int getUnitOnOrder() {
        return unitOnOrder;
    }

    public void setUnitOnOrder(int unitOnOrder) {
        this.unitOnOrder = unitOnOrder;
    }

    public int getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    public int getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    

}
